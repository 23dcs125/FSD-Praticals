import React, {useState, useEffect} from "react";
import axios from "axios";
import StudentForm from "../components/StudentForm";

const API_ROOT = import.meta.env.VITE_API_ROOT || "https://<YOUR_FIREBASE_REGION>-<PROJECT>.cloudfunctions.net/api";

export default function AdminDashboard(){
  const [students, setStudents] = useState([]);
  const [editing, setEditing] = useState(null);

  async function load(){
    try{
      const res = await axios.get(`${API_ROOT}/students`);
      setStudents(res.data);
    }catch(e){ console.error(e); }
  }

  useEffect(()=>{ load(); }, []);

  return <>
    <div className="grid md:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg p-6 shadow">
        <h2 className="text-xl font-medium mb-4">{editing ? "Edit Student" : "Add Student"}</h2>
        <StudentForm onSaved={()=>{ load(); setEditing(null); }} editing={editing} setEditing={setEditing}/>
      </div>

      <div className="bg-white rounded-lg p-6 shadow overflow-auto">
        <h2 className="text-xl font-medium mb-4">Students</h2>
        <div className="space-y-3">
          {students.map(s => (
            <div key={s._id} className="flex items-center justify-between border p-3 rounded">
              <div>
                <div className="font-semibold">{s.name}</div>
                <div className="text-sm text-slate-500">{s.className} • {s.contact}</div>
              </div>
              <div className="flex gap-2">
                <button onClick={()=> setEditing(s)} className="px-3 py-1 bg-blue-600 text-white rounded">Edit</button>
                <button onClick={async ()=>{
                  if(!confirm("Delete?")) return;
                  await axios.delete(`${API_ROOT}/students/${s._id}`); load();
                }} className="px-3 py-1 bg-red-600 text-white rounded">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </>
}
