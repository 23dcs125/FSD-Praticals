import React, {useEffect, useState} from "react";
import axios from "axios";

const API_ROOT = import.meta.env.VITE_API_ROOT;

export default function StudentForm({onSaved, editing, setEditing}){
  const [form, setForm] = useState({ name: "", age: "", className: "", contact: "" });

  useEffect(()=> {
    if(editing) setForm(editing);
  }, [editing]);

  async function submit(e){
    e.preventDefault();
    try{
      if(editing) await axios.put(`${API_ROOT}/students/${editing._id}`, form);
      else await axios.post(`${API_ROOT}/students`, form);
      setForm({ name: "", age: "", className: "", contact: "" });
      setEditing && setEditing(null);
      onSaved();
    }catch(e){ alert("Failed: " + e.message); }
  }

  return <form onSubmit={submit} className="space-y-3">
    <input className="w-full border rounded p-2" placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
    <input className="w-full border rounded p-2" placeholder="Age" value={form.age} onChange={e=>setForm({...form, age:e.target.value})}/>
    <input className="w-full border rounded p-2" placeholder="Class" value={form.className} onChange={e=>setForm({...form, className:e.target.value})}/>
    <input className="w-full border rounded p-2" placeholder="Contact" value={form.contact} onChange={e=>setForm({...form, contact:e.target.value})}/>
    <div className="flex gap-2">
      <button className="px-4 py-2 bg-green-600 text-white rounded">{editing ? "Update" : "Add"}</button>
      {editing && <button type="button" onClick={()=>{ setEditing(null); setForm({name:"",age:"",className:"",contact:""}); }} className="px-4 py-2 bg-gray-300 rounded">Cancel</button>}
    </div>
  </form>
}
