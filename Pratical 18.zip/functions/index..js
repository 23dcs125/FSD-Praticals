const functions = require("firebase-functions");
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const Student = require("./models/Student");

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

// Replace process.env.MONGO_URI usage with functions config (set later)
const MONGO_URI = functions.config().mongo.uri;

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(()=> console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB connect error", err));

// CRUD routes for Student
app.get("/students", async (req, res) => {
  try { const students = await Student.find(); res.json(students); }
  catch(e){ res.status(500).json({ error: e.message }); }
});

app.post("/students", async (req, res) => {
  try { const s = await Student.create(req.body); res.status(201).json(s); }
  catch(e){ res.status(400).json({ error: e.message }); }
});

app.put("/students/:id", async (req, res) => {
  try { const s = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true }); res.json(s); }
  catch(e){ res.status(400).json({ error: e.message }); }
});

app.delete("/students/:id", async (req, res) => {
  try { await Student.findByIdAndDelete(req.params.id); res.json({ success: true }); }
  catch(e){ res.status(500).json({ error: e.message }); }
});

// Expose Express app as Firebase Function
exports.api = functions.https.onRequest(app);
