const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();

// Ensure uploads folder exists
const uploadDir = "uploads";
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Storage config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

// PDF only filter
function fileFilter(req, file, cb) {
  if (file.mimetype === "application/pdf") {
    cb(null, true);
  } else {
    cb(new Error("Only PDF files are allowed!"), false);
  }
}

// Multer setup
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 }, // 2MB
  fileFilter,
});

// Root route
app.get("/", (req, res) => {
  res.send(`
    <h2>Upload your Resume (PDF only, max 2MB)</h2>
    <form action="/upload" method="post" enctype="multipart/form-data">
      <input type="file" name="resume" />
      <button type="submit">Upload</button>
    </form>
  `);
});

// Upload route
app.post("/upload", upload.single("resume"), (req, res) => {
  res.send("Resume uploaded successfully!");
});

// Error handling
app.use((err, req, res, next) => {
  if (err.code === "LIMIT_FILE_SIZE") {
    return res.status(400).send("File too large! Max size is 2MB.");
  }
  res.status(400).send(err.message);
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
