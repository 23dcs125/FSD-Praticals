const express = require("express");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = 5000;

// Middleware
app.use(express.urlencoded({ extended: true })); // for form data
app.use(
  session({
    secret: "supersecretkey",
    resave: false,
    saveUninitialized: true,
  })
);

// Set EJS as view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Routes

// Login Page
app.get("/", (req, res) => {
  res.render("login");
});

// Handle Login
app.post("/login", (req, res) => {
  const username = req.body.username;
  if (username) {
    req.session.username = username;
    req.session.loginTime = new Date().toLocaleString();
    return res.redirect("/profile");
  }
  res.redirect("/");
});

// Profile Page
app.get("/profile", (req, res) => {
  if (req.session.username) {
    res.render("profile", {
      username: req.session.username,
      loginTime: req.session.loginTime,
    });
  } else {
    res.redirect("/");
  }
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.log(err);
    }
    res.redirect("/");
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
