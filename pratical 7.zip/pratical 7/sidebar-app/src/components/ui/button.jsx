export function Button({ children, ...props }) {
  return (
    <button
      className="px-3 py-2 rounded-lg bg-gray-800 text-white hover:bg-gray-700 transition"
      {...props}
    >
      {children}
    </button>
  );
}
