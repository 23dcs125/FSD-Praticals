import { useState } from "react";
import { motion } from "framer-motion";
import { Home, User, Settings, LogOut } from "lucide-react";
import { Button } from "./ui/button";   // ✅ relative import, no @

const menuItems = [
  { name: "Home", icon: <Home size={20} />, roles: ["admin", "user"] },
  { name: "Profile", icon: <User size={20} />, roles: ["user", "admin"] },
  { name: "Settings", icon: <Settings size={20} />, roles: ["admin"] },
  { name: "Logout", icon: <LogOut size={20} />, roles: ["admin", "user"] },
];

export default function SidebarMenu({ userRole = "user" }) {
  const [isOpen, setIsOpen] = useState(false);
  const [active, setActive] = useState("Home");

  return (
    <div className="flex">
      <motion.aside
        initial={{ width: 60 }}
        animate={{ width: isOpen ? 220 : 60 }}
        transition={{ duration: 0.3 }}
        className="h-screen bg-gray-900 text-white flex flex-col shadow-lg"
      >
        {/* Toggle */}
        <div className="p-4 flex justify-end">
          <Button onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? "←" : "→"}
          </Button>
        </div>

        {/* Menu */}
        <nav className="flex-1 px-2 space-y-2">
          {menuItems
            .filter((item) => item.roles.includes(userRole))
            .map((item) => (
              <motion.div
                key={item.name}
                whileHover={{ scale: 1.05 }}
                onClick={() => setActive(item.name)}
                className={`flex items-center gap-3 cursor-pointer rounded-xl p-3 transition-colors duration-200 
                  ${active === item.name ? "bg-blue-600" : "hover:bg-gray-700"}`}
              >
                {item.icon}
                {isOpen && <span>{item.name}</span>}
              </motion.div>
            ))}
        </nav>
      </motion.aside>

      <main className="flex-1 p-6">
        <h1 className="text-2xl font-bold">{active} Page</h1>
      </main>
    </div>
  );
}
