import SidebarMenu from "./components/SidebarMenu";

export default function App() {
  return <SidebarMenu userRole="admin" />;
}
