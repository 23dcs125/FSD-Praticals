require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Student = require('./models/Student');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.error('MongoDB Error:', err));

// Routes

// Home - Show All Students
app.get('/', async (req, res) => {
  const students = await Student.find();
  res.render('index', { students });
});

// Add Student
app.post('/add', async (req, res) => {
  const { name, age, class: studentClass, contact } = req.body;
  await Student.create({ name, age, class: studentClass, contact });
  res.redirect('/');
});

// Edit Student
app.post('/edit/:id', async (req, res) => {
  const { id } = req.params;
  const { name, age, class: studentClass, contact } = req.body;
  await Student.findByIdAndUpdate(id, { name, age, class: studentClass, contact });
  res.redirect('/');
});

// Delete Student
app.get('/delete/:id', async (req, res) => {
  const { id } = req.params;
  await Student.findByIdAndDelete(id);
  res.redirect('/');
});

// Start Server
app.listen(process.env.PORT, () => console.log(`🚀 Server running at http://localhost:${process.env.PORT}`));
