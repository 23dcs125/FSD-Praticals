const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Set EJS as template engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Show tax form
app.get("/", (req, res) => {
  res.render("index", { error: null });
});

// Handle form submission
app.post("/calculate", (req, res) => {
  const { income1, income2 } = req.body;

  const inc1 = parseFloat(income1);
  const inc2 = parseFloat(income2);

  // Validate input
  if (isNaN(inc1) || isNaN(inc2) || inc1 < 0 || inc2 < 0) {
    return res.render("index", { error: " Please enter valid positive numbers." });
  }

  const totalIncome = inc1 + inc2;

  res.render("result", { totalIncome });
});

// Start server
const PORT = 9000;
app.listen(PORT, () => {
  console.log(` Server running on http://localhost:${PORT}`);
});
