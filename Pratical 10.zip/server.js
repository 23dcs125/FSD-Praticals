const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Route to view log file
app.get('/logs', (req, res) => {
  const filePath = path.join(__dirname, 'logs', 'errors.txt');

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error("Error reading log file:", err);
      return res.status(500).send(`
        <h2 style="color:red;">⚠️ Failed to load log file.</h2>
        <p>Possible reasons:</p>
        <ul>
          <li>Log file not found at <code>${filePath}</code></li>
          <li>Permission issue or file locked</li>
        </ul>
      `);
    }

    // Display logs in HTML format
    res.send(`
      <html>
        <head>
          <title>Server Log Viewer</title>
          <style>
            body { font-family: monospace; background: #121212; color: #00ff9f; padding: 20px; }
            h2 { color: #00bcd4; }
            pre { background: #1e1e1e; padding: 15px; border-radius: 10px; overflow-x: auto; }
          </style>
        </head>
        <body>
          <h2>📄 Server Error Logs</h2>
          <pre>${data}</pre>
        </body>
      </html>
    `);
  });
});

// Home route
app.get('/', (req, res) => {
  res.send(`
    <h1>Welcome to the Log Viewer Tool</h1>
    <p><a href="/logs">Click here to view error logs</a></p>
  `);
});

// Handle invalid routes
app.use((req, res) => {
  res.status(404).send("<h3>404 - Page Not Found</h3>");
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
