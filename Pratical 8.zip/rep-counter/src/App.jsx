import { useState, useEffect } from "react";

export default function App() {
  const [count, setCount] = useState(0);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("repCount");
    if (saved) setCount(Number(saved));
  }, []);

  // Save to localStorage whenever count changes
  useEffect(() => {
    localStorage.setItem("repCount", count);
  }, [count]);

  return (
    <div className="h-screen flex flex-col items-center justify-center bg-gray-100 text-gray-900">
      <h1 className="text-4xl font-bold mb-6">🏋️ Rep Counter</h1>

      <div className="text-7xl font-extrabold mb-6">{count}</div>

      <div className="flex gap-4">
        <button
          onClick={() => setCount((c) => Math.max(0, c - 1))}
          className="px-6 py-4 text-3xl bg-red-500 text-white rounded-2xl shadow-md active:scale-95 transition"
        >
          −
        </button>

        <button
          onClick={() => setCount((c) => c + 1)}
          className="px-6 py-4 text-3xl bg-green-500 text-white rounded-2xl shadow-md active:scale-95 transition"
        >
          +
        </button>
      </div>

      <button
        onClick={() => setCount(0)}
        className="mt-6 px-4 py-2 bg-gray-700 text-white rounded-xl shadow-md active:scale-95 transition"
      >
        Reset
      </button>
    </div>
  );
}
