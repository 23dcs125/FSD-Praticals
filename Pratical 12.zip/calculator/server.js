const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

// Routes
app.get("/", (req, res) => {
  res.render("index", { result: null, error: null });
});
const path = require("path");
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");


app.post("/calculate", (req, res) => {
  let { num1, num2, operation } = req.body;

  // Convert to numbers
  num1 = parseFloat(num1);
  num2 = parseFloat(num2);

  // Input validation
  if (isNaN(num1) || isNaN(num2)) {
    return res.render("index", { result: null, error: "❌ Please enter valid numbers!" });
  }

  let result;

  switch (operation) {
    case "add":
      result = num1 + num2;
      break;
    case "subtract":
      result = num1 - num2;
      break;
    case "multiply":
      result = num1 * num2;
      break;
    case "divide":
      if (num2 === 0) {
        return res.render("index", { result: null, error: "❌ Cannot divide by zero!" });
      }
      result = num1 / num2;
      break;
    default:
      return res.render("index", { result: null, error: "❌ Invalid operation!" });
  }

  res.render("index", { result, error: null });
});

// Start server
app.listen(PORT, () => {
  console.log(` Calculator app running at http://localhost:${PORT}`);
});
