// server.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Route: Home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route: Handle form submission
app.post('/send', async (req, res) => {
  const { name, email, message } = req.body;

  // Validation
  if (!name || !email || !message) {
    return res.send('<h2 style="color:red;">Please fill in all fields.</h2><a href="/">Go Back</a>');
  }

  // Debugging: check if .env is loaded
  console.log("Email user:", process.env.EMAIL_USER);
  console.log("Email pass:", process.env.EMAIL_PASS ? "Loaded ✅" : "Missing ❌");

  // Configure NodeMailer Transporter
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  // Email content
  const mailOptions = {
    from: process.env.EMAIL_USER, // your email (not the user's)
    to: process.env.EMAIL_USER,   // send to yourself
    subject: `Portfolio Message from ${name}`,
    text: `You received a message from your portfolio site.\n\nName: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('✅ Email sent successfully!');
    res.send('<h2 style="color:green;">Message sent successfully!</h2><a href="/">Go Back</a>');
  } catch (error) {
    console.error('❌ Email send error:', error);
    res.send('<h2 style="color:red;">Failed to send message. Try again later.</h2><a href="/">Go Back</a>');
  }
});

// Start Server
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));

